import UIKit

class carFeatures {
   var feature1 = "color"
   var feature2 = "model"
   var feature3 = "engine"
   var feature4 = "upholstery"
}

let features = carFeatures()
print( "I would like to select the \(features.feature1)")
